#' Setup for processing.
#'
#' Set-up for processing either a single video or multiple videos.
#'
#' @param settings_path the path to the video settings file
#' @param batch analyze either a single video (batch = FALSE) or multiple videos (batch = TRUE)
#' @param data_dir path to directory holding multiple videos (ignored for batch = FALSE)
#' @param data_results path to directory where results are stored (ignored for batch = FALSE)
#' @return selects video file(s) and initiates analysis
#' @examples
#' @export



kin_setup <- function(analysis.mode, data_dir, settings_file, results_dir, video.ID.no, plots) {


if(analysis.mode == "DAQ") {
        data_dir    <- "./"
        results_dir <- "./"
        video.ID.no <- NULL
        video.filename.list <- list.files(data_dir, pattern = glob2rx("*.csv*"), full.names=FALSE)
        video.filename      <- video.filename.list[1]
        video.ID            <- str_sub(video.filename, start = 1L, end = 5L)
        settings.list       <- list.files(data_dir, pattern = glob2rx("*.txt*"), full.names=FALSE)
        settings_path       <- paste0("./", settings.list)
        kin_process(video.filename, video.ID, settings_path, data_dir, results_dir, plots)
  }


if (analysis.mode == "single") {
        video.ID            <- video.ID.no
        video.ID.DLC        <- paste0(video.ID, "DLC")
        video.filename.list <- list.files(data_dir, pattern = glob2rx("*.csv*"), full.names=FALSE)
        video.filename.df   <- as.data.frame(video.filename.list)
        video.filename1     <- video.filename.df %>% filter(grepl(video.ID.DLC, video.filename.list))
        video.filename      <- video.filename1[[1]]
        settings.list       <- list.files(data_dir, pattern = glob2rx("*.txt*"), full.names=FALSE)
        settings_path       <- paste0(data_dir, "/", settings.list)
        data_dir            <- paste0(data_dir, "/")
        results_dir         <- "./"
        kin_process(video.filename, video.ID, settings_path, data_dir, results_dir, plots)
   }


if (analysis.mode == "batch") {
        data_dir            <- paste0(data_dir, "/")  # directory holding multiple .csv files
        results_dir         <- paste0(results_dir, "/")

        settings.list       <- list.files(data_dir, pattern = glob2rx("*.txt*"), full.names=FALSE)
        settings_path       <- paste0(data_dir, "/", settings.list)
        video.filename.list <- list.files(data_dir, pattern = glob2rx("*.csv*"), full.names=FALSE)

   # now loop through video.filename.list, analyzing each video one-by-one

          for(i in 1:length(video.filename.list)){
              video.filename    <- video.filename.list[i]
              video.ID          <- str_sub(video.filename, start = 1L, end = 5L)
              kin_process(video.filename, video.ID, settings_path, data_dir, results_dir, plots)
          }
    }

}



