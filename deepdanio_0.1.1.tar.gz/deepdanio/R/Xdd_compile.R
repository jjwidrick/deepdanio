
# this function is used to read a batch of kinematic results files and
#  compile them into dataframes (df's) suitable for further analysis


dd_compile <- function(project, data_dir, results_dir, metadata_file) {
  
}

  
# project(<your_project_name>)
# - give your project a short, one word name
#
# data_dir(<path_to_directory>) 
# - indicate the path to the directory containing your kinematic results, i.e. the `all_ms.csv` and `one_row.csv` files output by `dd_kinematics`. These are considered the data files for dd_compile. 
#
# results_dir(<path_to_directory>)
# - indicate the path to the directory for storing your compiled results
#
# metadata_file(<path_to_file>) 
# - indicate the path to and name of your metadata file. This file contains information about your fish, their phenotype, genotype, age, treatment, etc.   
